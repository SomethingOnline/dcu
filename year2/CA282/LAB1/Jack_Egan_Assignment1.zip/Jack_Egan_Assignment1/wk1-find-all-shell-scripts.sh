#!/bin/sh
find . -type f -name "*.sh"
