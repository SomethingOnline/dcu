#!/bin/sh
mkdir -p files
tar -zxf files.tgz -C files/
