#!/bin/sh

grep "Mary" mary.txt
