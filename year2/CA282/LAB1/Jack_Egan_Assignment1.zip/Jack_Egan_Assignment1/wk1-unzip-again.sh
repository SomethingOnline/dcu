#!/bin/sh

mkdir $DIR
unzip -q files.zip -d $DIR
