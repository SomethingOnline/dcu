#!/bin/sh
find . -type d -print
