#!/bin/sh
find . -type d -empty
